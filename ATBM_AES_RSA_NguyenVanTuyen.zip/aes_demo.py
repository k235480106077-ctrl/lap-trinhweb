from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os

def encrypt_aes(message: str, key: bytes):
    nonce = os.urandom(12)
    aes = AESGCM(key)
    ciphertext = aes.encrypt(nonce, message.encode("utf-8"), None)
    return nonce, ciphertext

def decrypt_aes(nonce: bytes, ciphertext: bytes, key: bytes):
    aes = AESGCM(key)
    plaintext = aes.decrypt(nonce, ciphertext, None)
    return plaintext.decode("utf-8")

if __name__ == "__main__":
    key = AESGCM.generate_key(bit_length=256)
    message = "Bai tap An toan va Bao mat thong tin - Nguyen Van Tuyen"

    nonce, ciphertext = encrypt_aes(message, key)
    recovered = decrypt_aes(nonce, ciphertext, key)

    print("Plaintext :", message)
    print("Key (hex) :", key.hex())
    print("Nonce     :", nonce.hex())
    print("Ciphertext:", ciphertext.hex())
    print("Decrypted :", recovered)
    print("Kiem tra  :", "THANH CONG" if recovered == message else "THAT BAI")
