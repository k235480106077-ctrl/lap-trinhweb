import os
import time
import statistics
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes

def measure(fn, rounds=100):
    values = []
    for _ in range(rounds):
        t0 = time.perf_counter_ns()
        fn()
        values.append(time.perf_counter_ns() - t0)
    return statistics.mean(values) / 1_000_000

# AES-256-GCM: encrypt/decrypt a 1 KiB message
aes_key = AESGCM.generate_key(bit_length=256)
aes = AESGCM(aes_key)
aes_data = os.urandom(1024)
aes_nonce = os.urandom(12)
aes_ciphertext = aes.encrypt(aes_nonce, aes_data, None)

aes_enc_ms = measure(
    lambda: aes.encrypt(os.urandom(12), aes_data, None)
)
aes_dec_ms = measure(
    lambda: aes.decrypt(aes_nonce, aes_ciphertext, None)
)

# RSA-2048 OAEP: RSA is not intended for large messages.
# We therefore use a short message within the OAEP size limit.
private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
public_key = private_key.public_key()
rsa_data = b"RSA benchmark message"
rsa_ciphertext = public_key.encrypt(
    rsa_data,
    padding.OAEP(
        mgf=padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None,
    ),
)

rsa_enc_ms = measure(
    lambda: public_key.encrypt(
        rsa_data,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )
)
rsa_dec_ms = measure(
    lambda: private_key.decrypt(
        rsa_ciphertext,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )
)

print("=== SO SANH THOI GIAN AES VA RSA ===")
print(f"AES-256-GCM encrypt 1 KiB : {aes_enc_ms:.4f} ms")
print(f"AES-256-GCM decrypt 1 KiB : {aes_dec_ms:.4f} ms")
print(f"RSA-2048 OAEP encrypt     : {rsa_enc_ms:.4f} ms")
print(f"RSA-2048 OAEP decrypt     : {rsa_dec_ms:.4f} ms")
print()
print("Luu y: day la phep do tren mot may cu the, khong phai hang so co dinh.")
print("RSA khong duoc dung de ma hoa truc tiep du lieu lon nhu AES.")
