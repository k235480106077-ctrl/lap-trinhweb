# Bài tập An toàn và Bảo mật thông tin

**Sinh viên:** Nguyễn Văn Tuyến

## Nội dung theo yêu cầu giảng viên

1. Tìm hiểu DES, AES: mô tả thuật toán và quy trình mã hóa/giải mã; cài đặt AES.
2. Tìm hiểu RSA: nguyên lý sinh cặp khóa bí mật/công khai.
3. Trình bày ứng dụng RSA cho xác thực người gửi, người nhận và cả hai; so sánh thời gian AES/RSA; mô hình kết hợp RSA + AES.

## Chạy chương trình

Cài Python 3, sau đó:

```bash
pip install -r requirements.txt
python aes_demo.py
python benchmark.py
```

## Cấu trúc

- `bao_cao_ATBM_NguyenVanTuyen.docx`: báo cáo
- `aes_demo.py`: demo AES-256-GCM mã hóa/giải mã
- `benchmark.py`: đo thời gian AES và RSA trên cùng máy
- `requirements.txt`: thư viện Python cần thiết
- `README.md`: hướng dẫn chạy

> Không đưa khóa thật, mật khẩu, token hoặc dữ liệu cá nhân nhạy cảm lên GitHub.
